package data;

/**
 * User: jpipe
 * Date: 12/5/12
 * Time: 4:24 PM
 */
public class LibraryConflictException extends Exception {

    public LibraryConflictException(String message) {
        super(message);
    }

}
